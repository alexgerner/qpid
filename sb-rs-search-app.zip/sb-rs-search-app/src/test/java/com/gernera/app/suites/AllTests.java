package com.gernera.app.suites;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.gernera.app.tests.TestsPatternSearch;
import com.gernera.app.tests.TestsValidateFindIDByRegExp;
import com.gernera.app.tests.TestsValidateInputParameters;

@RunWith(Suite.class)
@SuiteClasses({TestsPatternSearch.class,TestsValidateFindIDByRegExp.class,TestsValidateInputParameters.class})
public class AllTests {

}
