package com.gernera.app.tests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.gernera.utils.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class TestsValidateInputParameters {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void validateNoInputParameters() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " no parameters");
		MvcResult result = this.mockMvc.perform(get("/list?"))
		.andDo(print())
		.andExpect(status().isOk())
		.andReturn();
		
		String content = result.getResponse().getContentAsString();
		Assert.assertTrue(content.indexOf("Wrong Input Parameters:")>-1);
		
	}
	@Test
	public void validateNameIsNull() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " no parameters");
		MvcResult result = this.mockMvc.perform(get(Constants.requestNameIsNull))
		.andDo(print())
		.andExpect(status().isOk())
		.andReturn();
		String content = result.getResponse().getContentAsString();
		Assert.assertTrue(content.indexOf("Name cannot be null")>-1);
		
	}
	@Test
	public void validateNameisEmpty() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " no parameters");
		MvcResult result = this.mockMvc.perform(get(Constants.requestNameIsEmpty))
		.andDo(print())
		.andExpect(status().isOk())
		.andReturn();
		String content = result.getResponse().getContentAsString();
		Assert.assertTrue(content.indexOf("Name cannot be null")>-1);
		
	}
	@Test
	public void validateSearchObjectIsNull() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " no parameters");
		MvcResult result = this.mockMvc.perform(get(Constants.requestSearchObjectIsNull))
		.andDo(print())
		.andExpect(status().isOk())
		.andReturn();
		String content = result.getResponse().getContentAsString();
		Assert.assertTrue(content.indexOf("SearchObject cannot be null")>-1);
		
	}
}
