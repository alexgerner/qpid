package com.gernera.app;

import java.util.List;

import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import com.gernera.utils.Constants;


public class ApplicationParametersValidationErrors {
	public String ParseInputPametersErrors(Errors errors) {
		
			List<FieldError> fieldErrors = errors.getFieldErrors();
			StringBuffer sb = new StringBuffer();
			sb.append(" [ ");
			for (FieldError fieldError: fieldErrors) {
				sb.append(" Error: ");
				sb.append(fieldError.getDefaultMessage());
			}
			sb.append(" ] ");
			return (Constants.messageWrongArguments+sb.toString());
		
	}
}
