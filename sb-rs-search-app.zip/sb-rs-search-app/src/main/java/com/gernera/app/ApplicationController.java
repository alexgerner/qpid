package com.gernera.app;

import java.util.Map;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gernera.request.PatientObject;
import com.gernera.services.SearchPatientService;
import com.gernera.utils.Constants;

@RestController
public class ApplicationController {

	private static final Logger logger = LoggerFactory.getLogger(ApplicationController.class);
	
	private ApplicationProperties applicationProperties;

	@RequestMapping
	public String controllerMethod(@Valid PatientObject patientObject, Errors errors) {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		logger.info(methodName + Constants.messageStarted);
		if (errors!=null&&errors.hasFieldErrors()) {
			return new ApplicationParametersValidationErrors().ParseInputPametersErrors(errors);
		}
		Map<String, Map<String, String>> responseMap = new SearchPatientService().searchPatient(patientObject,
				applicationProperties);
		String applicationResponse = new ApplicationResponse().generateResponse(patientObject, responseMap);
		logger.info(methodName + Constants.messageFinished);

		return applicationResponse;

	}
}
