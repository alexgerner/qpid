package com.gernera.app;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import com.gernera.request.PatientObject;
import com.gernera.utils.Constants;

public class ApplicationResponse {
	private static final Logger logger = LoggerFactory.getLogger(ApplicationResponse.class);
	public synchronized String generateResponse(PatientObject patientObject, Map<String, Map<String, String>> responseMap) {
		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
		logger.info(methodName+Constants.messageStarted); 
		StringBuffer sb = new StringBuffer(); 
		sb.append(Constants.patientName+patientObject.getName());
		sb.append(" "+Constants.patientId+patientObject.getPatientId());
		responseMap.forEach((fileName,patternMap)->{
			sb.append(Constants.file+fileName);
			sb.append(" "+patternMap);
		
		});
		logger.info(methodName+Constants.messageFinished); 
		return sb.toString();
	}
}