package com.gernera.services;

import com.gernera.app.ApplicationProperties;
import com.gernera.request.PatientObject;
import com.gernera.request.SearchObject;
import com.gernera.utils.Constants;
import com.gernera.utils.FileToContents;
import com.gernera.utils.PatternSearch;
import com.gernera.utils.RegexpPrecompileSingleton;
import com.gernera.utils.SplitPatterns;
import com.gernera.utils.UniqueID;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchPatientService {
	private static final Logger logger = LoggerFactory.getLogger(SearchPatientService.class);
	public synchronized Map<String, Map<String, String>> searchPatient(PatientObject patientObject, ApplicationProperties applicationProperties) {
		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	logger.info(methodName+Constants.messageStarted); 
		String patientId = null;
		List<String> regexpList = applicationProperties.getRegexp();
		List<String> separatorList = applicationProperties.getSeparator();
		RegexpPrecompileSingleton regexpPrecompileSingleton = RegexpPrecompileSingleton.getInstance(regexpList);
		LinkedHashSet<Pattern> regexpSetPrecompile = regexpPrecompileSingleton.precompiledRegexpSet;
		Map<String, Map<String, String>> resourceMap = new LinkedHashMap<String, Map<String, String>>();
		for (SearchObject searchObject : patientObject.getSearchObject()) {
			if ((patientObject.getName()!=null)&&(!patientObject.getName().isEmpty())) {
				UUID id = new UniqueID().getUniqueID(); //unique internal UUID. No need to return this value to customer. Potentially should be saved in LDAP or DB.
				patientObject.setUuid(id);
				
			}
			String resource=searchObject.getResource();
			String content=new FileToContents().getContent(resource).toUpperCase();
			String searchString=resource.toUpperCase()+content;
			String[] patterns = new SplitPatterns().splitStringBySeparator(searchObject.getPatterns(), separatorList);
			Map<String, String> patternMap = new LinkedHashMap<String, String>();
			for (String pattern : patterns) {
				String matchedResult=new PatternSearch().patternMatchSearh(searchString, pattern);
				patternMap.put(pattern,matchedResult);
			}
			if (patientObject.getPatientId()==null) {
				patientId=new SearchPatientID().findIdByRegExp(content, regexpSetPrecompile);
				patientObject.setPatientId(patientId);
			}
			resourceMap.put(resource, patternMap);
		}
		
		logger.info(methodName+Constants.messageFinished); 
		return resourceMap;
	}


}
