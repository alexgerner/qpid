package com.gernera.request;

import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotEmpty;

public class PatientObject {
	@NotEmpty(message = "Name cannot be null")
	private String name;
	
	private String patientId;
	
	private UUID uuid;
	@NotEmpty(message = "SearchObject cannot be null")
	private List<SearchObject> searchObject;
	
	public List<SearchObject> getSearchObject() {
		return searchObject;
	}
	public void setSearchObject(List<SearchObject> searchObject) {
		this.searchObject = searchObject;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public UUID getUuid() {
		return uuid;
	}
	public void setUuid(UUID id) {
		this.uuid = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	





	
}

