package com.gernera.request;

public class SearchObject {
	
	
	private String patterns; 
	
	private String resource;

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public String getPatterns() {
		return patterns;
	}
	public void setPatterns(String patterns) {
		this.patterns = patterns;
	}

	public static SearchObject create() {
		return new SearchObject();
	}
	
	
}