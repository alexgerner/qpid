package com.gernera.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

public final class RegexpPrecompileSingleton {
	private static final Logger logger = LoggerFactory.getLogger(RegexpPrecompileSingleton.class);
	private static RegexpPrecompileSingleton regexpPrecompileSingleInstance = null;
	public LinkedHashSet<Pattern> precompiledRegexpSet;

	private RegexpPrecompileSingleton(List<String> regexpList) {
		LinkedHashSet<String> regexpSet = new LinkedHashSet<String>(regexpList); // elimimite duplicates
		LinkedHashSet<Pattern> regexpSetPrecomile = new LinkedHashSet<Pattern>();
		for (String regexp : regexpSet) {
			regexpSetPrecomile.add(Pattern.compile(regexp));
		}
		this.precompiledRegexpSet = regexpSetPrecomile;
	}

	// thread safe double-checked locking implementation.
	public static RegexpPrecompileSingleton getInstance(List<String> regexpList) {
		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	logger.info(methodName+Constants.messageStarted); 
		if (regexpPrecompileSingleInstance == null) {
			synchronized (RegexpPrecompileSingleton.class) {
				if (regexpPrecompileSingleInstance == null) {
					regexpPrecompileSingleInstance = new RegexpPrecompileSingleton(regexpList);
				}
			}
		}
	 	logger.info(methodName+Constants.messageFinished); 
		return regexpPrecompileSingleInstance;
	}
}