package com.gernera.utils;

import java.util.ArrayList;
import java.util.List;

public class PatternSearch {
	public String patternMatchSearh(String searchString, String pattern) {
		pattern=pattern.toUpperCase();
		if (searchString.indexOf(pattern)!=-1)
			return Constants.match;
		else {
			String patterns[] = pattern.split(Constants.words_separator);
			List<String> list = new ArrayList<String>();
			for (String pat : patterns) {
				if (searchString.indexOf(pat)!=-1) {
					list.add(pat);
				}
			}
			if (!list.isEmpty()) {
				StringBuffer sb = new StringBuffer(); // thread safe
				sb.append(Constants.partualmatch);
				sb.append("(");
				for (String pat : list) {
					sb.append(",");
					sb.append(pat);
				}
				sb.append(")");
				return sb.toString().replaceFirst(",", "");
				}
		}

		return Constants.nomatch;
	}

}