package com.gernera.utils;

public class Constants {
	private Constants() { } // Prevents instantiation 
	public static final String messageStarted = " Started";
	public static final String messageFinished = " Finished";
	public static final String messageDefault = "Please provide Input Parameters. e.g:	http://localhost:8080/list?name=***&patient%5B0%5D.patterns=***:::***:::&patient%5B0%5D.resource=***.txt";
	public static final String messageWrongArguments = "Wrong Input Parameters: ";
	public static final String dataDirectory = "data";
	public static final String match = "match";
	public static final String partualmatch = "partual match";
	public static final String nomatch = "no match";
	public static final String patientName = " Patient Name:";
	public static final String patientId = " Patient Id:";
	public static final String file = " File: ";
	
	// unit testing
	public static final String regexp1="(?<=PATIENT_NAME\\W{1,2})(\\w+)";
	public static final String regexp2="(?<=MRN#\\W{1,2})(\\w+)";
	public static final String regexp3="(?<=EDVISIT^\\s).*(?=\\s^PATIENT)";
	public static final String separator1=":::::";
	public static final String separator2=":::";
	public static final String words_separator=" ";
	public static final String request1NoMatch="http://localhost:8080/list?patient%5B0%5D.name=Mary TestPerson&patient%5B0%5D.patterns=Patient Note:::6/20/2010:::&patient%5B0%5D.resource=Mary_1.txt&patient%5B1%5D.patterns=Patient Note:::6/20/2010:::&patient%5B1%5D.resource=Mary_2.txt";
	public static final String request2NoMatch="http://localhost:8080/list?patient%5B0%5D.name=Joe TestPerson&patient%5B0%5D.patterns=Clinical Note:::4/6/2010:::&patient%5B0%5D.resource=Joe_1.txt&patient%5B1%5D.patterns=Summary:::7/2/2010:::&patient%5B1%5D.resource=Joe_2.txt";
	public static final String request3NoMatch="http://localhost:8080/list?patient%5B0%5D.name=Sam TestPerson&patient%5B0%5D.patterns=Patient Note:::8/3/2012:::&patient%5B0%5D.resource=Sam_1.txt";
	public static final String request4PartualMatch="http://localhost:8080/list?patient%5B0%5D.name=Mary TestPerson&patient%5B0%5D.patterns=Patient Note:::4/4/11:::&patient%5B0%5D.resource=Mary_1.txt&patient%5B1%5D.patterns=Patient Note:::6/20/2010:::&patient%5B1%5D.resource=Mary_2.txt";
	public static final String request5PartualMatch="http://localhost:8080/list?patient%5B0%5D.name=Joe TestPerson&patient%5B0%5D.patterns=EMR NOTE:::4/6/2010:::&patient%5B0%5D.resource=Joe_1.txt&patient%5B1%5D.patterns=Summary:::6/15/08:::&patient%5B1%5D.resource=Joe_2.txt";
	public static final String requestNameIsNull="/list?searchObject%5B0%5D.patterns=Patient%20Note:::6/20/2010:::&searchObject%5B0%5D.resource=Mary_1.txt&searchObject%5B1%5D.patterns=Patient%20Note:::6/20/2010:::&searchObject%5B1%5D.resource=Mary_2.txt";
	public static final String requestNameIsEmpty="/list?name=&searchObject%5B0%5D.patterns=Patient%20Note:::6/20/2010:::&searchObject%5B0%5D.resource=Mary_1.txt&searchObject%5B1%5D.patterns=Patient%20Note:::6/20/2010:::&searchObject%5B1%5D.resource=Mary_2.txt";
	public static final String requestSearchObjectIsNull="/list?name=Mary";
	
}

       