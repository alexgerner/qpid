package com.gernera.utils;

import java.util.UUID;

public class UniqueID {

	// thread safe
	public synchronized UUID getUniqueID() {
		UUID uniqueKey = UUID.randomUUID();
		System.out.println(uniqueKey);
		return uniqueKey;
	}

}
