package com.gernera.utils;

import java.util.UUID;

public class UniqueID {

	public synchronized UUID getUniqueID() {
		UUID uniqueKey = UUID.randomUUID();
		return uniqueKey;
	}

}
