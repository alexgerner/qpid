package com.qpidhealth.qpid.app.tests;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.Test;
import org.junit.Assert;

import com.qpidhealth.qpid.search.services.SearchPatientID;
import com.qpidhealth.qpid.utils.FileToContents;
import com.qpidhealth.qpid.utils.RegexpPrecompileSingleton;


public class TestsValidateFindIDByRegExp {
	
	

	@Test
	public void validateFindExistingIDByRegExp() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 String resource="Mary_1.txt";
		 List<String> regexpList = new ArrayList<String>();
		 regexpList.add("(?<=PATIENT_NAME\\W{1,2})(\\w+)");
		 regexpList.add("(?<=MRN#\\W{1,2})(\\w+)");
		 regexpList.add("(?<=MRN:\\\\W{1,2})(\\\\w+)");
		 regexpList.add("(?<=EDVISIT^\\s).*(?=\\s^PATIENT)");		
		 RegexpPrecompileSingleton regexpPrecompileSingleton = RegexpPrecompileSingleton.getInstance(regexpList);
		 LinkedHashSet<Pattern> regexpSetPrecompile = regexpPrecompileSingleton.precompiledRegexpSet;
		 String content=resource.toUpperCase()+new FileToContents().getContent(resource).toUpperCase();
	     String patientID=new SearchPatientID().findIdByRegExp(content, regexpSetPrecompile);
	  	 Assert.assertEquals(patientID,"0000003");
	
	}
	
	@Test
	public void validateFindNotExistingIDByRegExp() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 String resource="Joe_1.txt";
		 List<String> regexpList = new ArrayList<String>();
		 regexpList.add("(?<=PATIENT_NAME\\W{1,2})(\\w+)");
		 regexpList.add("(?<=MRN#\\W{1,2})(\\w+)");
		 regexpList.add("(?<=MRN:\\\\W{1,2})(\\\\w+)");
		 regexpList.add("(?<=EDVISIT^\\s).*(?=\\s^PATIENT)");		
		 RegexpPrecompileSingleton regexpPrecompileSingleton = RegexpPrecompileSingleton.getInstance(regexpList);
		 LinkedHashSet<Pattern> regexpSetPrecompile = regexpPrecompileSingleton.precompiledRegexpSet;
		 String content=resource.toUpperCase()+new FileToContents().getContent(resource).toUpperCase();
	     String patientID=new SearchPatientID().findIdByRegExp(content, regexpSetPrecompile);
	  	 Assert.assertEquals(patientID,"");
	
	}
	
}
