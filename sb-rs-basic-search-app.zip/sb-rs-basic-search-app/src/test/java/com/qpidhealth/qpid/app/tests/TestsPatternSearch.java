package com.qpidhealth.qpid.app.tests;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.Assert;

import com.qpidhealth.qpid.app.ApplicationParametersValidator;
import com.qpidhealth.qpid.patient.Patient;
import com.qpidhealth.qpid.patient.PatientList;
import com.qpidhealth.qpid.utils.Constants;
import com.qpidhealth.qpid.utils.FileToContents;
import com.qpidhealth.qpid.utils.PatternSearch;


public class TestsPatternSearch {
	
	
	@Test
	public void validatePartualDoubleMatch() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 String resource="Mary_1.txt";
		 String pattern="REASON NOTE";
		 String content=new FileToContents().getContent(resource).toUpperCase();
	     String resultMatch=new PatternSearch().patternMatchSearh(content, pattern);
	  	 Assert.assertEquals(resultMatch,Constants.partualmatch+"(REASON,NOTE)");
	
	}
	@Test
	public void validatePartualSingleMatch() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 String resource="Mary_1.txt";
		 String pattern="Alex NOTE";
		 String content=new FileToContents().getContent(resource).toUpperCase();
	     String resultMatch=new PatternSearch().patternMatchSearh(content, pattern);
	  	 Assert.assertEquals(resultMatch,Constants.partualmatch+"(NOTE)");
	
	}
	@Test
	public void validateFullMatch() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 String resource="Mary_1.txt";
		 String pattern="ReasoN For";
		 String content=new FileToContents().getContent(resource).toUpperCase();
	     String resultMatch=new PatternSearch().patternMatchSearh(content, pattern);
	  	 Assert.assertEquals(resultMatch,Constants.match);
	
	}
	@Test
	public void validateFileNameMatch() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 String resource="Mary_1.txt";
		 String pattern="Mary_1 FrF";
		 String content=resource.toUpperCase()+new FileToContents().getContent(resource).toUpperCase();
	     String resultMatch=new PatternSearch().patternMatchSearh(content, pattern);
	  	 Assert.assertEquals(resultMatch,Constants.partualmatch+"(MARY_1)");
	
	}
	
	@Test
	public void validateNoMatch() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 String resource="Mary_1.txt";
		 String pattern="ReasN FrF";
		 String content=new FileToContents().getContent(resource).toUpperCase();
	     String resultMatch=new PatternSearch().patternMatchSearh(content, pattern);
	  	 Assert.assertEquals(resultMatch,Constants.nomatch);
	
	}
}
