package com.qpidhealth.qpid.app.tests;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.Assert;

import com.qpidhealth.qpid.app.ApplicationParametersValidator;
import com.qpidhealth.qpid.patient.Patient;
import com.qpidhealth.qpid.patient.PatientList;
import com.qpidhealth.qpid.utils.Constants;


public class TestsValidateInputParameters {
	
	
	@Test
	public void validateNoInputParameters() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 
		 PatientList patientList = new PatientList();
		 boolean result= new ApplicationParametersValidator().validateInputPameters(patientList);
		 Assert.assertFalse(result);
	}
	@Test
	public void validateBadInputParameterName() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		 System.out.println(methodName);
		 Patient patient1 = new Patient();
		 patient1.setPatterns("Patient Note:::6/20/2010:::");
		 patient1.setResource("Mary_1.txt");
		 Patient patient2 = new Patient();
		 patient2.setPatterns("Patient Note:::6/20/2010:::");
		 patient2.setResource("Mary_2.txt");
		 List<Patient> myList = new ArrayList<Patient>();
		 myList.add(patient1);
		 myList.add(patient2);
		 PatientList patientList = new PatientList();
		 patientList.setPatient(myList);
	     boolean result= new ApplicationParametersValidator().validateInputPameters(patientList);
		 Assert.assertFalse(result);
	
	}
	@Test
	public void validateGoodInputParameterName() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Patient patient1 = new Patient();
		 patient1.setName("Mary TestPerson");
		 patient1.setPatterns("Patient Note:::6/20/2010:::");
		 patient1.setResource("Mary_1.txt");
		 Patient patient2 = new Patient();
		 patient2.setPatterns("Patient Note:::6/20/2010:::");
		 patient2.setResource("Mary_2.txt");
		 List<Patient> myList = new ArrayList<Patient>();
		 myList.add(patient1);
		 myList.add(patient2);
		 PatientList patientList = new PatientList();
		 patientList.setPatient(myList);
	     boolean result= new ApplicationParametersValidator().validateInputPameters(patientList);
		 Assert.assertTrue(result);
	
	}
}
