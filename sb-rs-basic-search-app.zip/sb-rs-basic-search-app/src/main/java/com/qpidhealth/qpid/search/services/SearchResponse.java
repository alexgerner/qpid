package com.qpidhealth.qpid.search.services;

import java.util.Map;

public class SearchResponse {
	private String id;
	private String name;
	private Map<String, Map<String, String>> responseMap;
	public String getName() {
		return name;
	}
	public void setName(final String name) {
		this.name = name;
	}
	public Map<String, Map<String, String>> getResponseMap() {
		return responseMap;
	}
	public void setResponseMap(Map<String, Map<String, String>> responseMap) {
		this.responseMap = responseMap;
	}
	
	public String getId() {
		return id;
	}
	public void setId(final String id) {
		this.id = id;
	}
	
}
