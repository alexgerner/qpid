package com.qpidhealth.qpid.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qpidhealth.qpid.patient.PatientList;
import com.qpidhealth.qpid.search.services.SearchPatientService;
import com.qpidhealth.qpid.search.services.SearchResponse;
import com.qpidhealth.qpid.utils.Constants;

@RestController
public class ApplicationController {
	
	private static final Logger logger = LoggerFactory.getLogger(ApplicationController.class);
	@Autowired
	private  ApplicationProperties applicationProperties;
	@RequestMapping("list")
    public String controllerMethod(PatientList patientList) {
  		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	logger.info(methodName+Constants.messageStarted);
    	if (new ApplicationParametersValidator().validateInputPameters(patientList)==false) return Constants.messageWrongArguments;
    	SearchResponse searchResponse = new SearchPatientService().searchPatient(patientList,applicationProperties);
    	String applicationResponse = new ApplicationResponse().generateRSRespons(searchResponse);
       	logger.info(methodName+Constants.messageFinished); 
    	return applicationResponse;
    }

    
}


