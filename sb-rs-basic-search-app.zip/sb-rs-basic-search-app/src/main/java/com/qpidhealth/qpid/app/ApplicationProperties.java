package com.qpidhealth.qpid.app;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@ConfigurationProperties(prefix = "app")
@Component
public class ApplicationProperties {
		
	private List<String> regexp;
	private List<String> separator;
	
	public List<String> getSeparator() {
		return separator;
	}
	public void setSeparator(List<String> separator) {
		this.separator = separator;
	}
	public List<String> getRegexp() {
		return regexp;
	}
	public void setRegexp(List<String> regexp) {
		this.regexp = regexp;
	}
	
	
	
	
}


