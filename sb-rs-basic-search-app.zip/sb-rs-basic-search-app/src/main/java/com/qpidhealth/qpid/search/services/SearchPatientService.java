package com.qpidhealth.qpid.search.services;

import com.qpidhealth.qpid.app.ApplicationProperties;
import com.qpidhealth.qpid.patient.Patient;
import com.qpidhealth.qpid.patient.PatientList;
import com.qpidhealth.qpid.utils.Constants;
import com.qpidhealth.qpid.utils.FileToContents;
import com.qpidhealth.qpid.utils.PatternSearch;
import com.qpidhealth.qpid.utils.RegexpPrecompileSingleton;
import com.qpidhealth.qpid.utils.SplitPatterns;
import com.qpidhealth.qpid.utils.UniqueID;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchPatientService {
	private static final Logger logger = LoggerFactory.getLogger(SearchPatientService.class);
	public synchronized SearchResponse searchPatient(PatientList patientList, ApplicationProperties applicationProperties) {
		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	logger.info(methodName+Constants.messageStarted); 
		String name = null;
		String patientId = null;
		List<String> regexpList = applicationProperties.getRegexp();
		List<String> separatorList = applicationProperties.getSeparator();
		RegexpPrecompileSingleton regexpPrecompileSingleton = RegexpPrecompileSingleton.getInstance(regexpList);
		LinkedHashSet<Pattern> regexpSetPrecompile = regexpPrecompileSingleton.precompiledRegexpSet;
		SearchResponse searchResponse = new SearchResponse();
		Map<String, Map<String, String>> resourceMap = new LinkedHashMap<String, Map<String, String>>();
		
		for (Patient patient : patientList.getPatient()) {
			if ((patient.getName()!=null)&&(!patient.getName().isEmpty())) {
				name= patient.getName();
				UUID id = new UniqueID().getUniqueID(); //unique internal UUID. No need to return this value to customer. Potentially should be saved in LDAP or DB.
				patient.setId(id);
				searchResponse.setName(name);
			}
			String resource=patient.getResource();
			String content=new FileToContents().getContent(resource).toUpperCase();
			String searchString=resource.toUpperCase()+content;
			String[] patterns = new SplitPatterns().splitStringBySeparator(patient.getPatterns(), separatorList);
			Map<String, String> patternMap = new LinkedHashMap<String, String>();
			for (String pattern : patterns) {
				String matchedResult=new PatternSearch().patternMatchSearh(searchString, pattern);
				patternMap.put(pattern,matchedResult);
			}
			if (searchResponse.getId()==null) {
				patientId=new SearchPatientID().findIdByRegExp(content, regexpSetPrecompile);
				searchResponse.setId(patientId);
			}
			resourceMap.put(resource, patternMap);
		}
		searchResponse.setResponseMap(resourceMap);
		logger.info(methodName+Constants.messageFinished); 
		return searchResponse;
	}


}
