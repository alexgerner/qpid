package com.qpidhealth.qpid.app;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map;
import com.qpidhealth.qpid.utils.Constants;

import com.qpidhealth.qpid.search.services.SearchResponse;

public class ApplicationResponse {
	private static final Logger logger = LoggerFactory.getLogger(ApplicationResponse.class);
	public synchronized String generateRSRespons(SearchResponse searchResponse) {
		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	logger.info(methodName+Constants.messageStarted); 
		String name=searchResponse.getName();
		String id=searchResponse.getId();
		Map<String, Map<String, String>> responseMap=searchResponse.getResponseMap();
		StringBuffer sb = new StringBuffer(); /* thread safe */
		sb.append(Constants.patientName+name);
		sb.append(" "+Constants.patientId+id);
		sb.append(" "+responseMap);
		logger.info(methodName+Constants.messageFinished); 
		return sb.toString();
	}
}