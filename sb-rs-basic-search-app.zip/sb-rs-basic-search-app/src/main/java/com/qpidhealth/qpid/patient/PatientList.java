package com.qpidhealth.qpid.patient;

import java.util.List;

public class PatientList {

	private List<Patient> patient;

	public List<Patient> getPatient() {
		return patient;
	}

	public void setPatient(List<Patient> patient) {
		this.patient = patient;
	}

	
}

