package com.qpidhealth.qpid.app;

import com.qpidhealth.qpid.patient.Patient;
import com.qpidhealth.qpid.patient.PatientList;

public class ApplicationParametersValidator {
	public boolean validateInputPameters(PatientList patientList) {
		if (patientList.getPatient()==null) return false;
		int i=0;
		for (Patient patient: patientList.getPatient()) {
			if (i==0&&patient.getName()==null) return false;
			else if (patient.getPatterns()==null) return false;
			else if (patient.getResource()==null) return false;
			else i++;
		}
		return true;
	}
	
}
