package com.qpidhealth.qpid.utils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class FileToContents {
	private static final Logger logger = LoggerFactory.getLogger(FileToContents.class);
	public String getContent(String fileName) {
		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	logger.info(methodName+Constants.messageStarted); 
	    String path = Constants.dataDirectory +File.separator + fileName;
		Resource resource = new ClassPathResource(path);
		String content = null;
		try {
			content = new String(Files.readAllBytes(resource.getFile().toPath()), StandardCharsets.UTF_8);
		} catch (IOException e) {
		     e.printStackTrace();
		}
	 	logger.info(methodName+Constants.messageFinished); 	
		return content;
	}
}
