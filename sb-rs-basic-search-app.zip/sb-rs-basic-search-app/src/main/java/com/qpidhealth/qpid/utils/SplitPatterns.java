package com.qpidhealth.qpid.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

public class SplitPatterns {
	private static final Logger logger = LoggerFactory.getLogger(SplitPatterns.class);
	public String[] splitStringBySeparator(String stringToSplit, List<String> separatorList) {
		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	logger.info(methodName+Constants.messageStarted); 
		String[] splittedPatterns = null;
		for (String separator : separatorList) {
			if (stringToSplit.indexOf(separator) < 0) {
				continue;
			}
			splittedPatterns = stringToSplit.split(separator);
			break;
		}
		logger.info(methodName+Constants.messageFinished); 
		return splittedPatterns;

	}
}
