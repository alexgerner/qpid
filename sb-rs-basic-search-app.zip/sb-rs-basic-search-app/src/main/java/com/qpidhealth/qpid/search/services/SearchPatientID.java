package com.qpidhealth.qpid.search.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.LinkedHashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.qpidhealth.qpid.utils.Constants;

public class SearchPatientID {
	private static final Logger logger = LoggerFactory.getLogger(SearchPatientID.class);
	public synchronized String findIdByRegExp(final String content, final LinkedHashSet<Pattern> regexpSetPrecomile) {
		String methodName = new Object() {}.getClass().getEnclosingMethod().getName();
    	logger.info(methodName+Constants.messageStarted); 
		if (content == null || content.length() == 0 || regexpSetPrecomile == null
				|| regexpSetPrecomile.size() == 0) {
			return "empty";
		}
		String patientId = "";
		for (Pattern pattern : regexpSetPrecomile) {
			Matcher m = pattern.matcher(content);
			while (m.find()) {
			patientId=m.group(1);
			System.out.println(patientId);
			}
		}
		logger.info(methodName+Constants.messageFinished); 
		return patientId;
	}
}
